# RoleFit — CV × JD Career Studio

Website tiếng Việt phân tích JD và CV theo bằng chứng, có kết quả có thể sửa, xuất CV Word `.docx`, so sánh nhiều JD và chatbot hỏi tiếp. Xây theo quy trình 6 bước do chủ dự án cung cấp.

## Trạng thái chức năng

| Chức năng | Mở file web không có backend | Đã triển khai Netlify Functions + AI |
|---|---|---|
| Giao diện, nhập JD/CV, sửa CV | Có | Có |
| Xem báo cáo minh họa (dữ liệu giả rõ nhãn) | Có | Có |
| Trích chữ TXT | Có | Có |
| Trích chữ PDF/DOCX | Có, khi có Internet để tải PDF.js/Mammoth | Có, khi có Internet |
| Đính kèm ảnh JD | Chỉ chuẩn bị ảnh, không đọc bằng AI | Có — AI phân tích ảnh JPEG/PNG/WEBP |
| Phân tích JD/CV thực bằng AI | **Không** | **Có** |
| So sánh các kết quả bằng AI | **Không** | **Có** |
| Chatbot có phản hồi AI | **Không** | **Có** |
| Sao chép văn bản, lưu Markdown, xuất `.docx` Harvard một cột | Có khi có báo cáo minh họa | Có sau phân tích |

> Không nhầm báo cáo minh họa với kết quả thực tế. Website không tự biết CV của bạn trong tài khoản ChatGPT; cần tải file hoặc dán CV. File xuất Word phải được bạn đọc, sửa và xác nhận trước khi nộp.

## Cách nhanh nhất: Xem thử giao diện (không có AI)

1. Giải nén gói này.
2. Vào thư mục `public`.
3. Nhấp đúp `index.html` để mở trình duyệt, chọn **Xem bản minh họa**.
4. Muốn đăng bản **chỉ có giao diện và demo**: đăng nhập Netlify, mở https://app.netlify.com/drop và **kéo thư mục `public` đã giải nén** vào trang. Không kéo ZIP trực tiếp nếu Netlify đang yêu cầu thư mục.

Cách này không chạy serverless functions nên phân tích và chatbot AI sẽ báo chưa kết nối. **Để có AI thật, dùng cách bên dưới.**

## Xuất bản website ĐẦY ĐỦ trên Netlify

Netlify Functions cần được triển khai theo đúng quy trình build/deploy có hỗ trợ functions. Khuyên dùng GitHub → Netlify hoặc Netlify CLI; không giả định rằng kéo một thư mục static lên Netlify Drop sẽ triển khai backend.

### Phương án A — GitHub (không cần lệnh terminal để triển khai)

1. Tạo repository riêng tư trên GitHub (nên chọn Private để hạn chế người khác thay đổi mã nguồn). Upload **toàn bộ nội dung** thư mục `RoleFit-CV-JD-Netlify` vào root repository, giữ nguyên `netlify.toml`, `public/`, `netlify/functions/`.
2. Vào https://app.netlify.com/ → **Add new project** → **Import an existing project** → chọn repo GitHub.
3. Dùng `netlify.toml` đã có: publish directory là `public`, functions directory là `netlify/functions`; không cần build command.
4. Trong **Project configuration → Environment variables**, tạo:
   - `OPENAI_API_KEY`: API key từ tài khoản API OpenAI của bạn. **Không chia sẻ key, không ghi vào file HTML hoặc GitHub.**
   - `APP_ACCESS_CODE`: mã truy cập dài, khó đoán, chỉ cấp cho người được phép dùng AI (không đăng công khai).
   - `OPENAI_MODEL` (không bắt buộc): mặc định `gpt-4.1-mini`; đổi sang model bạn có quyền truy cập khi cần.
5. Triển khai lại site sau khi đặt biến môi trường để functions nhận được giá trị mới.
6. Mở địa chỉ `https://<ten-site>.netlify.app`, nhấn **⚙ Thiết lập**, nhập mã `APP_ACCESS_CODE`, tick đồng ý gửi CV/JD rồi thử **Phân tích**.
7. Xác nhận đủ: báo trạng thái "Máy chủ AI đã cấu hình", phân tích JD, xem bảng đối chiếu, xuất Word, chatbot, so sánh 2 báo cáo.

### Phương án B — Netlify CLI (dành cho người quen dòng lệnh)

Cài Node.js, sau đó trong **thư mục gốc dự án** (cùng chỗ có `netlify.toml`) chạy:

```bash
npx netlify-cli login
npx netlify-cli init
npx netlify-cli deploy --prod
```

Cần xác nhận cấu hình Site/Team theo hướng dẫn trên màn hình. Chỉnh environment variables trên Netlify UI và triển khai lại sau đó.

## Về API và chi phí

- ChatGPT Plus/Pro **không đồng nghĩa** có ngân sách OpenAI API. API được tính phí riêng theo mức sử dụng.
- Tránh công khai `APP_ACCESS_CODE`. Nếu muốn mở AI cho người lạ, cần đăng nhập người dùng, quota/rate limiting và giới hạn chi phí ở cấp nhà cung cấp. Mã PIN dùng chung chỉ phù hợp thử nghiệm nhỏ/nhóm tin cậy, **không phải cơ chế chống lạm dụng hoàn chỉnh**.
- Functions gọi API với `store: false`; nhưng vẫn có hoạt động xử lý dữ liệu theo chính sách nhà cung cấp. Hạn chế đưa dữ liệu nhạy cảm không cần thiết vào CV/JD.
- CV/JD **không lưu trên máy chủ của website** theo mã nguồn hiện tại; trên trình duyệt chỉ được giữ trong bộ nhớ tab cho đến khi bạn bật tùy chọn "Cho phép lưu CV/JD trên thiết bị này". Xóa trình duyệt hoặc đóng phiên sẽ mất các báo cáo chưa xuất ra file.

## Dữ liệu đầu vào

- **JD**: dán text, `.txt`, `.md`, `.docx`, `.pdf` có text; có thể đính kèm tối đa 3 ảnh PNG/JPG/WEBP dưới 2,4MB/ảnh (chỉ AI backend mới đọc được ảnh).
- **CV**: dán text, `.txt`, `.md`, `.docx`, `.pdf` có text. CV PDF scan chưa OCR; hãy cung cấp bản có thể chọn chữ hoặc dán nội dung.
- Trích xuất PDF/DOCX sử dụng thư viện bên thứ ba tải qua CDN trong trình duyệt. Không tải được thư viện thì hãy dán text.
- File nào không đọc được sẽ hiện cảnh báo. Không giả vờ đã đọc nội dung bị thiếu.

## Bộ quy tắc đánh giá

1. Đọc toàn bộ JD: nhiệm vụ, tiêu chí, mandatory/preferred; phân biệt thông tin có trong JD với suy luận.
2. So CV với JD theo 4 trạng thái: đáp ứng tốt; một phần; chưa có bằng chứng; đã xác định chưa đáp ứng. Không chấm phần trăm phù hợp tùy tiện.
3. Nhận định ứng tuyển ngay / thử sức / nên bổ sung trước; cân nhắc chênh lệch thâm niên có ghi rõ.
4. Xuất CV Harvard một cột, có thể chỉnh sửa Word, riêng vị trí-công ty; không làm giả hoặc thêm số liệu, chức danh, công cụ, kinh nghiệm. Gợi ý cắt giảm không có nghĩa là tự cắt.
5. Bù kinh nghiệm bằng portfolio/dự án đã làm (không biến portfolio thành kinh nghiệm lao động); nêu phần cần xác minh.
6. Chỉ chọn tối đa 3 khoảng trống học, mỗi mục có bài thực hành, minh chứng đầu ra, tiêu chí hoàn thành, giờ dự kiến, thời điểm.

## Nâng cấp sau này

Để dùng công khai ở quy mô lớn: bổ sung tài khoản đăng nhập từng người, rate limit tại edge, hạn mức chi phí API, logging không chứa dữ liệu nhạy cảm, đồng bộ hồ sơ có mã hóa, OCR PDF scan, kiểm soát chất lượng cho CV Word và kiểm thử liên tục.

## Nguồn kỹ thuật

- Netlify deploy: https://docs.netlify.com/deploy/create-deploys/
- Netlify Functions: https://docs.netlify.com/build/functions/get-started/
- Netlify environment variables: https://docs.netlify.com/build/functions/environment-variables/
- OpenAI Responses API: https://developers.openai.com/api/docs/guides/text

**Lưu ý:** Chưa có địa chỉ website công khai của dự án này cho đến khi bạn thực sự triển khai vào Netlify.
