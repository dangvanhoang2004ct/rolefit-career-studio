# Triển khai RoleFit bằng GitHub Desktop và Netlify

> Website chưa được xuất bản. Cần GitHub và Netlify của chủ dự án; không gửi API key hoặc mã truy cập qua chat, ảnh chụp, file GitHub.

## 1. Đưa dự án lên GitHub (ít dùng lệnh nhất)

1. Giải nén `RoleFit-GitHub-Ready.zip`. Giữ nguyên cả thư mục `RoleFit-GitHub-Ready`, bao gồm thư mục `.git` ẩn đã có commit khởi tạo.
2. Mở https://desktop.github.com/ và đăng nhập GitHub.
3. Trong GitHub Desktop chọn **File → Add Local Repository → Choose**; chọn thư mục `RoleFit-GitHub-Ready` vừa giải nén.
4. Nhấn **Publish repository**, đặt tên ví dụ `rolefit-career-studio`, giữ **Keep this code private** được chọn, sau đó nhấn Publish.
5. Vào GitHub kiểm tra root repository có `netlify.toml`, thư mục `public/` và `netlify/functions/`.

Nếu GitHub Desktop không nhận `.git` do phần mềm giải nén bỏ qua thư mục ẩn, chọn **Create a repository here**, tạo commit đầu tiên rồi Publish. Không đưa `.env` hoặc file API key vào repository.

## 2. Tạo Netlify website từ GitHub

1. Mở https://app.netlify.com → Add new project → Import an existing project → GitHub.
2. Cấp quyền GitHub cho Netlify và chọn repository `rolefit-career-studio`.
3. Cấu hình root/base ở root của repo, **Publish directory = `public`**, **Functions directory = `netlify/functions`**, **Build command = bỏ trống**. File `netlify.toml` đã có các cấu hình tương ứng.
4. Nhấn **Publish / Deploy site**. Ghi lại URL `.netlify.app` mà Netlify cấp.

## 3. Thiết lập key bí mật chỉ bên Netlify

1. Vào **Project configuration → Environment variables**.
2. Thêm biến `OPENAI_API_KEY` = OpenAI API key của chủ website, đảm bảo Functions runtime có quyền đọc.
3. Thêm biến `APP_ACCESS_CODE` = mã truy cập dài, khó đoán, không trùng mật khẩu các tài khoản khác. Dùng mã này trong phần **Thiết lập** trên website để mở tính năng AI.
4. Tùy chọn `OPENAI_MODEL` = `gpt-4.1-mini` hoặc model được tài khoản API hỗ trợ.
5. **Trigger deploy → Deploy site** hoặc push commit mới sau khi tạo/chỉnh các biến.
6. Không điền giá trị thật vào repo, `.env.example`, `netlify.toml`, `public/index.html`, hoặc file JavaScript.

## 4. Kiểm tra trước khi chia sẻ

- Truy cập URL Netlify trên điện thoại và máy tính.
- Mở `/api/health` (địa chỉ dạng `https://ten-trang.netlify.app/api/health`), kiểm tra JSON báo `ready: true` sau khi thiết lập 2 biến môi trường.
- Tại website: mở **Thiết lập**, nhập APP_ACCESS_CODE; tải một CV và JD thử (không chứa dữ liệu nhạy cảm), đồng ý gửi dữ liệu AI rồi nhấn phân tích.
- Kiểm tra bảng đối chiếu 4 mức, xuất .docx, chatbot; sai mã phải bị chặn.
- Nếu cần chia sẻ công khai cho người lạ dùng AI, cần xác thực tài khoản, rate limit, quota/ngân sách API. Mã dùng chung chỉ phù hợp nhóm tin cậy.

## 5. Cập nhật về sau

Sửa file trong local repository → commit trong GitHub Desktop → **Push origin**. Netlify tự triển khai phiên bản mới từ nhánh đã kết nối.

Nguồn: https://docs.netlify.com/start/quickstarts/deploy-from-repository/ ; https://docs.netlify.com/build/functions/environment-variables/ ; https://docs.github.com/en/desktop/adding-and-cloning-repositories/adding-an-existing-project-to-github-using-github-desktop
